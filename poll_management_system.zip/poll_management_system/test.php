<?php

/*include 'dbcon.php';*/

/*$sql = "INSERT INTO `poll_questions` (`id`, `question`) VALUES (NULL, 'test')" ;

$query = mysqli_query($con,$sql);
*/
?>